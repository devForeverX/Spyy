# Signaling Server & Coturn STUN/TURN Infrastruktur

Diese Komponente stellt die eigenständige Netzwerk- und Signalisierungsinfrastruktur für die native Android Phone Remote Control App bereit.

---

## 1. Architekturüberblick

1. **Signalisierungsserver (Node.js / TypeScript)**:
   - WebSocket über TLS (WSS) auf Port 8443 (Entwicklungsmodus: HTTP/WS auf Port 8443).
   - Handhabt Geräteregistrierung, Weiterleitung von SDP Offer/Answer und ICE-Kandidaten ausschließlich zwischen verifizierten, gekoppelten Geräten (`pairingId`).
   - Erzwingt strikte Rate-Limits (max. 5 fehlgeschlagene Pairing-Versuche pro IP vor 15-minütiger Sperre) und ein 5-Minuten-TTL für Pairing-Codes.
   - Generiert dynamisch zeitlich begrenzte Ephemeral-Zugangsdaten (HMAC-SHA1) für den Coturn-Server.
   - Healthcheck-Endpunkt: `GET /healthz`.

2. **Coturn STUN / TURN Server**:
   - STUN auf Port 3478 (UDP/TCP) zur Ermittlung öffentlicher IP-Adressen für Direct P2P.
   - TURNS auf Port 5349 (TLS) für verschlüsseltes Relay bei symmetrischem NAT.
   - Dynamische REST API Authentifizierung ohne statische Passwörter in der Android-App.
   - Keine hart codierten Secrets in der Konfigurationsdatei; Authentifizierungs-Secrets werden zur Laufzeit aus der Umgebung synchronisiert.

---

## 2. Firewall- & Portfreigaben

Auf dem Host-Server müssen folgende Ports in der Firewall (z. B. `ufw` oder Cloud Security Group) freigegeben sein:

| Port | Protokoll | Zweck |
| :--- | :--- | :--- |
| **8443** | TCP | WebSocket-Signalisierung (WSS) |
| **3478** | UDP & TCP | Coturn STUN/TURN Standard |
| **5349** | UDP & TCP | Coturn TURNS über TLS |
| **49152 – 65535** | UDP | Coturn dynamische Relay-Port-Range |

Beispiel für Ubuntu UFW:
```bash
sudo ufw allow 8443/tcp
sudo ufw allow 3478/udp
sudo ufw allow 3478/tcp
sudo ufw allow 5349/tcp
sudo ufw allow 5349/udp
sudo ufw allow 49152:65535/udp
sudo ufw reload
```

---

## 3. Lokale Entwicklung & Tests

```bash
cd server
npm ci
npm run build
npm test
npm run dev
```

Die Tests prüfen:
- Generierung von Ephemeral TURN-Credentials (HMAC-SHA1).
- Rate-Limiting & Sperre nach Fehlversuchen.
- `/healthz` Healthcheck-Status.
- Registrierung und Keepalive.
- Ablehnung wiederholter/falsch sequenzierter Nachrichten.
- Zielgerät-erzeugtes PIN-Pairing, beidseitige Commit-Bestätigung und isoliertes Routing nur zwischen gekoppelten Peers.

Führe diese Befehle in einer Umgebung mit installierten Projektabhängigkeiten aus. Der aktuelle Container konnte `npm ci` aufgrund fehlender Netzwerkauflösung nicht ausführen; siehe `../FINAL_BUILD_REPORT.md` für den tatsächlich ausgeführten temporären Host-Test und seine Einschränkungen.

---

## 4. Bereitstellung mit Docker Compose

### Schritt 1: Umgebungsvariablen anlegen
```bash
cd server
cp .env.example .env
```
Generiere ein kryptografisches TURN-Auth-Secret:
```bash
openssl rand -hex 32
```
Trage dieses Secret in `.env` unter `COTURN_STATIC_AUTH_SECRET` ein.

### Schritt 2: TLS-Zertifikate (Let's Encrypt)
Für sichere WebRTC-Signalisierung und TURNS wird ein offizielles TLS-Zertifikat benötigt:
```bash
sudo certbot certonly --standalone -d turn.yourdomain.com
```
Kopiere oder verlinke die Zertifikatsdateien in `server/certs/`:
- `fullchain.pem`
- `privkey.pem`

### Schritt 3: Container bauen und starten
```bash
docker compose up -d --build
```

### Schritt 4: Health Check prüfen
```bash
curl -s http://localhost:8443/healthz
# bzw. bei TLS:
curl -s https://turn.yourdomain.com:8443/healthz
```
Coturn-Status prüfen:
```bash
docker compose logs -f coturn
```
