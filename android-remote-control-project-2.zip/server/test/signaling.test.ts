import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import crypto from 'node:crypto';
import { WebSocket } from 'ws';
import {
  createServerInstance,
  generateEphemeralTurnCredentials,
  checkRateLimit,
  recordFailedAttempt,
  resetRateLimit,
  rateLimits,
  MAX_ATTEMPTS,
  PROTOCOL_VERSION,
  computePairingId,
  trustedPairings
} from '../src/signaling.js';

type Message = {
  version: number;
  type: string;
  messageId?: string;
  sequenceNumber?: number;
  timestamp?: number;
  pairingId?: string;
  payload?: any;
};

const allSockets = new Set<WebSocket>();
let nextSequence = 1;

function connect(port: number): WebSocket {
  const ws = new WebSocket(`ws://127.0.0.1:${port}`);
  allSockets.add(ws);
  return ws;
}

function waitForMessage(ws: WebSocket, type: string, predicate: (msg: Message) => boolean = () => true, timeoutMs = 4000): Promise<Message> {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      ws.off('message', onMessage);
      reject(new Error(`Timed out waiting for ${type}`));
    }, timeoutMs);
    const onMessage = (raw: WebSocket.RawData) => {
      let msg: Message;
      try { msg = JSON.parse(raw.toString()) as Message; } catch { return; }
      if (msg.type !== type || !predicate(msg)) return;
      clearTimeout(timeout);
      ws.off('message', onMessage);
      resolve(msg);
    };
    ws.on('message', onMessage);
  });
}

function send(ws: WebSocket, type: string, payload: unknown, pairingId?: string): void {
  ws.send(JSON.stringify({
    version: PROTOCOL_VERSION,
    type,
    messageId: `test-${crypto.randomUUID()}`,
    sequenceNumber: nextSequence++,
    timestamp: Date.now(),
    ...(pairingId ? { pairingId } : {}),
    payload
  }));
}

async function open(ws: WebSocket): Promise<void> {
  if (ws.readyState === WebSocket.OPEN) return;
  await new Promise<void>((resolve, reject) => {
    ws.once('open', resolve);
    ws.once('error', reject);
  });
}

async function register(ws: WebSocket, port: number, deviceId: string, role: 'admin' | 'remote', identityPublicKeyBase64?: string) {
  await open(ws);
  const ackPromise = waitForMessage(ws, 'REGISTER_ACK');
  const icePromise = waitForMessage(ws, 'ICE_SERVERS');
  send(ws, 'REGISTER', { deviceId, role, identityPublicKeyBase64 });
  const [ack, ice] = await Promise.all([ackPromise, icePromise]);
  assert.equal(ack.payload.status, 'REGISTERED');
  assert.equal(ice.payload.iceServers.length, 2);
}

function makeEcIdentity() {
  const pair = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  return {
    privateKey: pair.privateKey,
    publicKeyBase64: pair.publicKey.export({ type: 'spki', format: 'der' }).toString('base64')
  };
}

const pause = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

describe('Native Android signaling protocol', () => {
  let server: http.Server;
  let serverPort = 0;

  before(async () => {
    const instance = createServerInstance();
    server = instance.server as http.Server;
    await new Promise<void>((resolve) => {
      server.listen(0, '127.0.0.1', () => {
        const address = server.address();
        if (typeof address === 'object' && address) serverPort = address.port;
        resolve();
      });
    });
  });

  after(async () => {
    for (const ws of allSockets) {
      if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) {
        try { ws.terminate(); } catch { /* cleanup only */ }
      }
    }
    await new Promise<void>((resolve) => server.close(() => resolve()));
  });

  test('TURN credentials use the expected temporary REST structure', () => {
    const credentials = generateEphemeralTurnCredentials('test-device', 3600);
    assert.equal(credentials.ttlSeconds, 3600);
    assert.equal(credentials.iceServers.length, 2);
    assert.ok(credentials.iceServers[0].urls.some((url: string) => url.startsWith('stun:')));
    assert.ok(credentials.iceServers[1].urls.some((url: string) => url.startsWith('turn:')));
    assert.ok(credentials.iceServers[1].username.includes('test-device'));
    assert.ok(credentials.iceServers[1].credential.length > 10);
  });

  test('rate limiting blocks after the configured number of invalid attempts', () => {
    const ip = '198.51.100.42';
    resetRateLimit(ip);
    for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
      assert.equal(checkRateLimit(ip), true);
      recordFailedAttempt(ip);
    }
    assert.equal(checkRateLimit(ip), false);
    resetRateLimit(ip);
    assert.equal(checkRateLimit(ip), true);
    assert.equal(rateLimits.has(ip), false);
  });

  test('health endpoint reports active status', async () => {
    const response = await new Promise<{ status: number; body: any }>((resolve, reject) => {
      http.get(`http://127.0.0.1:${serverPort}/healthz`, (res) => {
        let body = '';
        res.on('data', (part) => { body += part; });
        res.on('end', () => resolve({ status: res.statusCode || 0, body: JSON.parse(body) }));
      }).on('error', reject);
    });
    assert.equal(response.status, 200);
    assert.equal(response.body.status, 'healthy');
    assert.equal(response.body.version, PROTOCOL_VERSION);
    assert.ok(typeof response.body.trustedPairings === 'number');
  });

  test('REGISTER and PING/PONG use the same versioned envelope as Android', async () => {
    const ws = connect(serverPort);
    const identity = makeEcIdentity();
    await register(ws, serverPort, 'controller-test', 'admin', identity.publicKeyBase64);
    const pongPromise = waitForMessage(ws, 'PONG');
    send(ws, 'PING', { clientTimestamp: Date.now() });
    const pong = await pongPromise;
    assert.equal(typeof pong.payload.echoTimestamp, 'number');
  });

  test('replayed or out-of-order envelopes are rejected on a registered socket', async () => {
    const ws = connect(serverPort);
    const identity = makeEcIdentity();
    await register(ws, serverPort, 'replay-test-controller', 'admin', identity.publicKeyBase64);

    const envelope = {
      version: PROTOCOL_VERSION,
      type: 'PING',
      messageId: 'intentionally-replayed-message',
      sequenceNumber: nextSequence++,
      timestamp: Date.now(),
      payload: { clientTimestamp: Date.now() }
    };
    const pongPromise = waitForMessage(ws, 'PONG');
    ws.send(JSON.stringify(envelope));
    await pongPromise;
    const replayErrorPromise = waitForMessage(ws, 'ERROR', (m) => m.payload?.errorCode === 'REPLAYED_OR_OUT_OF_ORDER_MESSAGE');
    ws.send(JSON.stringify(envelope));
    assert.equal((await replayErrorPromise).payload.errorCode, 'REPLAYED_OR_OUT_OF_ORDER_MESSAGE');
  });

  test('target-first pairing requires both verified commits and isolates remote control routing', async () => {
    const admin = connect(serverPort);
    const target = connect(serverPort);
    const attacker = connect(serverPort);
    const adminIdentity = makeEcIdentity();
    const targetIdentity = makeEcIdentity();

    await Promise.all([
      register(admin, serverPort, 'controller-phone', 'admin', adminIdentity.publicKeyBase64),
      register(target, serverPort, 'target-phone', 'remote', targetIdentity.publicKeyBase64),
      register(attacker, serverPort, 'unpaired-third-party', 'admin', makeEcIdentity().publicKeyBase64)
    ]);

    const code = '749201';
    const badPinPayloadError = waitForMessage(target, 'ERROR', (m) => m.payload?.errorCode === 'INVALID_PAIRING_INIT');
    send(target, 'PAIRING_INIT', {
      code: '123890',
      deviceId: 'target-phone',
      deviceName: 'Target Android',
      ephemeralPublicKeyBase64: makeEcIdentity().publicKeyBase64,
      identityPublicKeyBase64: makeEcIdentity().publicKeyBase64,
      nonceBase64: Buffer.alloc(16, 6).toString('base64')
    });
    assert.equal((await badPinPayloadError).payload.errorCode, 'INVALID_PAIRING_INIT');

    const pinAck = waitForMessage(target, 'PAIRING_INIT_ACK');
    send(target, 'PAIRING_INIT', {
      code,
      deviceId: 'target-phone',
      deviceName: 'Target Android',
      ephemeralPublicKeyBase64: makeEcIdentity().publicKeyBase64,
      identityPublicKeyBase64: targetIdentity.publicKeyBase64,
      nonceBase64: Buffer.alloc(16, 7).toString('base64')
    });
    assert.equal((await pinAck).payload.code, code);

    const adminResponsePromise = waitForMessage(admin, 'PAIRING_RESPONSE');
    const targetHandshakePromise = waitForMessage(target, 'PAIRING_HANDSHAKE_INIT');
    send(admin, 'PAIRING_SUBMIT', {
      code,
      remoteDeviceId: 'controller-phone',
      deviceName: 'Controller Android',
      ephemeralPublicKeyBase64: makeEcIdentity().publicKeyBase64,
      identityPublicKeyBase64: adminIdentity.publicKeyBase64,
      nonceBase64: Buffer.alloc(16, 9).toString('base64')
    });
    const [response, handshake] = await Promise.all([adminResponsePromise, targetHandshakePromise]);
    assert.equal(response.payload.remoteDeviceId, 'target-phone');
    assert.equal(handshake.payload.adminDeviceId, 'controller-phone');
    assert.equal(response.pairingId, handshake.pairingId);

    const pairingId = computePairingId(adminIdentity.publicKeyBase64, targetIdentity.publicKeyBase64);
    assert.equal(response.pairingId, pairingId);

    const peerProofOnTarget = waitForMessage(target, 'PAIRING_CONFIRM');
    send(admin, 'PAIRING_CONFIRM', { pairingId, authProofBase64: Buffer.alloc(32, 1).toString('base64') }, pairingId);
    assert.equal((await peerProofOnTarget).payload.authProofBase64, Buffer.alloc(32, 1).toString('base64'));

    let successDelivered = false;
    const countSuccess = (raw: WebSocket.RawData) => {
      try { if ((JSON.parse(raw.toString()) as Message).type === 'PAIRING_SUCCESS') successDelivered = true; } catch { /* ignore */ }
    };
    admin.on('message', countSuccess);
    target.on('message', countSuccess);

    const peerProofOnAdmin = waitForMessage(admin, 'PAIRING_CONFIRM');
    send(target, 'PAIRING_CONFIRM', { pairingId, authProofBase64: Buffer.alloc(32, 2).toString('base64') }, pairingId);
    assert.equal((await peerProofOnAdmin).payload.authProofBase64, Buffer.alloc(32, 2).toString('base64'));
    await pause(30);
    assert.equal(successDelivered, false, 'server must not commit after SAS messages alone');

    const adminSuccessPromise = waitForMessage(admin, 'PAIRING_SUCCESS');
    const targetSuccessPromise = waitForMessage(target, 'PAIRING_SUCCESS');
    send(admin, 'PAIRING_COMMIT', { pairingId }, pairingId);
    send(target, 'PAIRING_COMMIT', { pairingId }, pairingId);
    const [adminSuccess, targetSuccess] = await Promise.all([adminSuccessPromise, targetSuccessPromise]);
    assert.equal(adminSuccess.payload.pairingId, pairingId);
    assert.equal(targetSuccess.payload.pairingId, pairingId);
    admin.off('message', countSuccess);
    target.off('message', countSuccess);

    const remoteActionPromise = waitForMessage(target, 'CONTROL_ACTION');
    send(admin, 'CONTROL_ACTION', { action: 'BACK' }, pairingId);
    const action = await remoteActionPromise;
    assert.equal(action.payload.action, 'BACK');
    assert.equal(action.pairingId, pairingId);

    const unauthorizedErrorPromise = waitForMessage(attacker, 'ERROR', (m) => m.payload?.errorCode === 'UNAUTHORIZED_PAIRING');
    send(attacker, 'CONTROL_ACTION', { action: 'HOME' }, pairingId);
    assert.equal((await unauthorizedErrorPromise).payload.errorCode, 'UNAUTHORIZED_PAIRING');

    // A pairing ID plus a copied/public identity is not sufficient; the private key must sign a fresh challenge.
    const reconnectedAdmin = connect(serverPort);
    await open(reconnectedAdmin);
    const challengePromise = waitForMessage(reconnectedAdmin, 'REGISTER_ACK', (m) => m.payload?.status === 'AUTH_REQUIRED');
    send(reconnectedAdmin, 'REGISTER', {
      deviceId: 'controller-phone-reconnected',
      role: 'admin',
      identityPublicKeyBase64: adminIdentity.publicKeyBase64,
      savedPairingId: pairingId
    });
    const challengeMessage = await challengePromise;
    const challengeBase64 = challengeMessage.payload.challengeBase64 as string;
    const signature = crypto.sign('sha256', Buffer.from(challengeBase64, 'base64'), adminIdentity.privateKey).toString('base64');
    const authenticatedPromise = waitForMessage(reconnectedAdmin, 'REGISTER_ACK', (m) => m.payload?.status === 'AUTHENTICATED');
    const authenticatedIcePromise = waitForMessage(reconnectedAdmin, 'ICE_SERVERS');
    send(reconnectedAdmin, 'REGISTER_AUTH', {
      pairingId,
      deviceId: 'controller-phone-reconnected',
      role: 'admin',
      identityPublicKeyBase64: adminIdentity.publicKeyBase64,
      challengeBase64,
      signatureBase64: signature
    }, pairingId);
    assert.equal((await authenticatedPromise).payload.status, 'AUTHENTICATED');
    assert.equal((await authenticatedIcePromise).type, 'ICE_SERVERS');

    const forged = connect(serverPort);
    await open(forged);
    const forgedErrorPromise = waitForMessage(forged, 'ERROR', (m) => m.payload?.errorCode === 'IDENTITY_MISMATCH');
    const fallbackAckPromise = waitForMessage(forged, 'REGISTER_ACK', (m) => m.payload?.status === 'REGISTERED');
    const fallbackIcePromise = waitForMessage(forged, 'ICE_SERVERS');
    send(forged, 'REGISTER', {
      deviceId: 'forged-controller',
      role: 'admin',
      identityPublicKeyBase64: makeEcIdentity().publicKeyBase64,
      savedPairingId: pairingId
    });
    assert.equal((await forgedErrorPromise).payload.errorCode, 'IDENTITY_MISMATCH');
    assert.equal((await fallbackAckPromise).payload.status, 'REGISTERED');
    assert.equal((await fallbackIcePromise).type, 'ICE_SERVERS', 'device should be able to re-pair after invalidating stale trust');

    assert.ok(trustedPairings.has(pairingId), 'successful pairing must be stored for reconnection');
  });
});
