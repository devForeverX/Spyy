import { WebSocketServer, WebSocket } from 'ws';
import http from 'http';
import https from 'https';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import dotenv from 'dotenv';

dotenv.config();

export const PROTOCOL_VERSION = 1;
export const MAX_MESSAGE_SIZE_BYTES = 65536;

const PORT = parseInt(process.env.SIGNALING_PORT || '8443', 10);
const NODE_ENV = process.env.NODE_ENV || 'development';
const COTURN_AUTH_SECRET = process.env.COTURN_STATIC_AUTH_SECRET || '';
const COTURN_REALM = process.env.COTURN_REALM || 'turn.example.com';
const COTURN_HOST = process.env.COTURN_HOST || 'turn.example.com';
const COTURN_PORT = parseInt(process.env.COTURN_PORT || '3478', 10);
const COTURN_TLS_PORT = parseInt(process.env.COTURN_TLS_PORT || '5349', 10);

const certPath = process.env.SSL_CERT_PATH;
const keyPath = process.env.SSL_KEY_PATH;

// Production security guards
if (NODE_ENV === 'production') {
  if (!COTURN_AUTH_SECRET || COTURN_AUTH_SECRET === 'CHANGE_THIS_IN_PRODUCTION_TURN_SECRET' || COTURN_AUTH_SECRET === 'generate_a_random_hex_secret_here') {
    console.error('FATAL [Security]: In production mode, COTURN_STATIC_AUTH_SECRET must be set to a secure random secret.');
    process.exit(1);
  }
  if (!certPath || !keyPath || !fs.existsSync(certPath) || !fs.existsSync(keyPath)) {
    console.error('FATAL [Security]: In production mode, valid SSL_CERT_PATH and SSL_KEY_PATH are mandatory for WSS/TURNS.');
    process.exit(1);
  }
}

// Rate Limiting Storage
interface RateLimitRecord {
  attempts: number;
  lockedUntil: number;
}
export const rateLimits = new Map<string, RateLimitRecord>();
export const MAX_ATTEMPTS = 5;
export const LOCKOUT_MS = 15 * 60 * 1000; // 15 Minutes
export const PAIRING_TTL_MS = 5 * 60 * 1000; // 5 Minutes

export function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const record = rateLimits.get(ip);
  if (!record) return true;
  if (record.lockedUntil > now) return false;
  if (record.lockedUntil <= now && record.attempts >= MAX_ATTEMPTS) {
    rateLimits.delete(ip);
  }
  return true;
}

export function recordFailedAttempt(ip: string) {
  const now = Date.now();
  const record = rateLimits.get(ip) || { attempts: 0, lockedUntil: 0 };
  record.attempts++;
  if (record.attempts >= MAX_ATTEMPTS) {
    record.lockedUntil = now + LOCKOUT_MS;
  }
  rateLimits.set(ip, record);
}

export function resetRateLimit(ip: string) {
  rateLimits.delete(ip);
}

// Active Sessions
export interface DeviceClient {
  ws: WebSocket;
  deviceId: string;
  role: 'admin' | 'remote';
  identityPublicKeyBase64?: string;
  pairingId?: string;
  ip: string;
  connectedAt: number;
  lastSequenceNumber?: number;
  recentMessageIds?: Set<string>;
}

export interface PendingPairing {
  targetWs: WebSocket;
  code: string;
  createdAt: number;
  targetDeviceId: string;
  targetDeviceName: string;
  targetEphemeralKeyBase64: string;
  targetIdentityKeyBase64: string;
  targetNonceBase64: string;
}

export const clients = new Map<WebSocket, DeviceClient>();
export const pendingPairings = new Map<string, PendingPairing>();

interface ActivePairing {
  pairingId: string;
  code: string;
  adminWs: WebSocket;
  remoteWs: WebSocket;
  adminIdentityKeyBase64: string;
  remoteIdentityKeyBase64: string;
  createdAt: number;
  confirmations: Set<WebSocket>;
  commits: Set<WebSocket>;
  committed: boolean;
}

export const activePairings = new Map<string, ActivePairing>();

interface TrustedPairing {
  pairingId: string;
  adminIdentityKeyBase64: string;
  remoteIdentityKeyBase64: string;
  createdAt: number;
}

interface RegistrationChallenge {
  pairingId: string;
  challenge: Buffer;
  deviceId: string;
  role: 'admin' | 'remote';
  identityPublicKeyBase64: string;
}

const PAIRINGS_FILE = process.env.PAIRINGS_FILE || path.join(process.cwd(), 'pairings.json');
export const trustedPairings = new Map<string, TrustedPairing>();
const registrationChallenges = new Map<WebSocket, RegistrationChallenge>();

function loadTrustedPairings(): void {
  try {
    if (!fs.existsSync(PAIRINGS_FILE)) return;
    const raw = JSON.parse(fs.readFileSync(PAIRINGS_FILE, 'utf8')) as TrustedPairing[];
    for (const pairing of raw) {
      if (pairing?.pairingId && pairing.adminIdentityKeyBase64 && pairing.remoteIdentityKeyBase64) {
        trustedPairings.set(pairing.pairingId, pairing);
      }
    }
  } catch (error) {
    console.error(`[Security] Could not load trusted pairings from ${PAIRINGS_FILE}:`, error);
  }
}

function persistTrustedPairings(): void {
  const tempPath = `${PAIRINGS_FILE}.tmp`;
  try {
    fs.mkdirSync(path.dirname(PAIRINGS_FILE), { recursive: true });
    fs.writeFileSync(tempPath, JSON.stringify([...trustedPairings.values()], null, 2), { mode: 0o600 });
    fs.renameSync(tempPath, PAIRINGS_FILE);
  } catch (error) {
    try { if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath); } catch { /* ignored */ }
    console.error(`[Security] Could not persist trusted pairings to ${PAIRINGS_FILE}:`, error);
    throw error;
  }
}

loadTrustedPairings();

/** Validate canonical SPKI DER for the same P-256 curve used by Android Keystore. */
function isValidP256PublicKeyBase64(value: unknown): value is string {
  if (typeof value !== 'string' || value.length < 80 || value.length > 1024) return false;
  try {
    const der = Buffer.from(value, 'base64');
    if (der.toString('base64') !== value) return false;
    const key = crypto.createPublicKey({ key: der, format: 'der', type: 'spki' });
    return key.asymmetricKeyType === 'ec' && key.asymmetricKeyDetails?.namedCurve === 'prime256v1';
  } catch {
    return false;
  }
}

function isValidNonceBase64(value: unknown): value is string {
  if (typeof value !== 'string') return false;
  try {
    const nonce = Buffer.from(value, 'base64');
    return nonce.length === 16 && nonce.toString('base64') === value;
  } catch {
    return false;
  }
}

function isValidAuthProofBase64(value: unknown): value is string {
  if (typeof value !== 'string') return false;
  try {
    const proof = Buffer.from(value, 'base64');
    return proof.length === 32 && proof.toString('base64') === value;
  } catch {
    return false;
  }
}

/** Register the socket as an unpaired device after a stale or invalid saved binding. */
function sendUnpairedRegistration(ws: WebSocket, deviceId: string, role: 'admin' | 'remote'): void {
  ws.send(JSON.stringify({
    version: PROTOCOL_VERSION,
    type: 'REGISTER_ACK',
    messageId: `ack_${crypto.randomUUID()}`,
    sequenceNumber: 0,
    timestamp: Date.now(),
    payload: { status: 'REGISTERED', deviceId, role }
  }));
  ws.send(JSON.stringify({
    version: PROTOCOL_VERSION,
    type: 'ICE_SERVERS',
    messageId: `ice_${crypto.randomUUID()}`,
    sequenceNumber: 0,
    timestamp: Date.now(),
    payload: generateEphemeralTurnCredentials(deviceId)
  }));
}

/** Must match PairingCrypto.computePairingId on Android exactly. */
export function computePairingId(identityKeyA: string, identityKeyB: string): string {
  const [first, second] = identityKeyA < identityKeyB
    ? [identityKeyA, identityKeyB]
    : [identityKeyB, identityKeyA];
  return crypto.createHash('sha256')
    .update(`${first}:${second}:AndroidRemote_v1`, 'utf8')
    .digest('base64url');
}

// Ephemeral Coturn credentials (REST API standard: timestamp:username, HMAC-SHA1)
export function generateEphemeralTurnCredentials(deviceId: string, ttlSeconds: number = 3600) {
  const secret = COTURN_AUTH_SECRET || 'dev_secret';
  const expiryTimestamp = Math.floor(Date.now() / 1000) + ttlSeconds;
  const username = `${expiryTimestamp}:${deviceId}`;
  const hmac = crypto.createHmac('sha1', secret);
  hmac.update(username);
  const password = hmac.digest('base64');

  return {
    iceServers: [
      { urls: [`stun:${COTURN_HOST}:${COTURN_PORT}`] },
      {
        urls: [
          `turn:${COTURN_HOST}:${COTURN_PORT}?transport=udp`,
          `turn:${COTURN_HOST}:${COTURN_PORT}?transport=tcp`,
          `turns:${COTURN_HOST}:${COTURN_TLS_PORT}?transport=tcp`
        ],
        username,
        credential: password
      }
    ],
    ttlSeconds
  };
}

// Wire Message Envelope
export interface WireEnvelope {
  version: number;
  type: string;
  messageId: string;
  sequenceNumber: number;
  timestamp: number;
  pairingId?: string;
  payload: any;
}

// Request Handler for HTTP / HTTPS (including /healthz)
export function handleHttpRequest(req: http.IncomingMessage, res: http.ServerResponse) {
  const url = req.url || '/';

  if (url === '/healthz' || url === '/api/health') {
    let adminCount = 0;
    let remoteCount = 0;
    for (const c of clients.values()) {
      if (c.role === 'admin') adminCount++;
      else if (c.role === 'remote') remoteCount++;
    }

    const payload = {
      status: 'healthy',
      version: PROTOCOL_VERSION,
      uptimeSeconds: Math.floor(process.uptime()),
      activeConnections: clients.size,
      activeAdmins: adminCount,
      activeRemotes: remoteCount,
      pendingPairings: pendingPairings.size,
      trustedPairings: trustedPairings.size,
      lockedIps: Array.from(rateLimits.entries()).filter(([_, r]) => r.lockedUntil > Date.now()).length,
      tlsEnabled: !!(certPath && keyPath && fs.existsSync(certPath) && fs.existsSync(keyPath)),
      timestamp: new Date().toISOString()
    };

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(payload));
    return;
  }

  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('Not Found');
}

// Setup HTTP / HTTPS server
export function createServerInstance(): { server: http.Server | https.Server; wss: WebSocketServer } {
  let server: http.Server | https.Server;

  if (certPath && keyPath && fs.existsSync(certPath) && fs.existsSync(keyPath)) {
    server = https.createServer(
      {
        cert: fs.readFileSync(certPath),
        key: fs.readFileSync(keyPath)
      },
      handleHttpRequest
    );
    console.log('Starting signaling server with TLS (WSS)...');
  } else {
    server = http.createServer(handleHttpRequest);
    console.log('Starting signaling server in plain HTTP/WS mode (Development)...');
  }

  const wss = new WebSocketServer({ server, maxPayload: MAX_MESSAGE_SIZE_BYTES });

  wss.on('connection', (ws: WebSocket, req: http.IncomingMessage) => {
    const rawIp = req.socket.remoteAddress || '127.0.0.1';
    const ip = rawIp.replace(/^::ffff:/i, ''); // normalize IPv6 mapped IPv4

    ws.on('close', () => {
      registrationChallenges.delete(ws);
      clients.delete(ws);
      for (const [code, pending] of pendingPairings.entries()) {
        if (pending.targetWs === ws) pendingPairings.delete(code);
      }
      for (const [pairingId, pairing] of activePairings.entries()) {
        if (pairing.adminWs === ws || pairing.remoteWs === ws) {
          if (!pairing.committed) activePairings.delete(pairingId);
        }
      }
    });

    ws.on('error', () => {
      // The close handler performs the same ephemeral-state cleanup; keep errors from
      // becoming unhandled EventEmitter errors without exposing details to remote peers.
    });

    ws.on('message', (data: string | Buffer) => {
      if (data.length > MAX_MESSAGE_SIZE_BYTES) {
        ws.send(JSON.stringify({
          version: PROTOCOL_VERSION,
          type: 'ERROR',
          messageId: `err_${Date.now()}`,
          sequenceNumber: 0,
          timestamp: Date.now(),
          payload: { errorCode: 'MESSAGE_TOO_LARGE', errorMessage: 'Nachricht überschreitet maximales Limit von 64KB' }
        }));
        return;
      }

      try {
        const message: WireEnvelope = JSON.parse(data.toString());
        const { type, payload, messageId, sequenceNumber, pairingId } = message;

        if (message.version !== PROTOCOL_VERSION || typeof messageId !== 'string' || !messageId ||
            !Number.isSafeInteger(sequenceNumber) || sequenceNumber < 0) {
          ws.send(JSON.stringify({
            version: PROTOCOL_VERSION,
            type: 'ERROR',
            messageId: `err_${crypto.randomUUID()}`,
            sequenceNumber: 0,
            timestamp: Date.now(),
            payload: { errorCode: 'INVALID_ENVELOPE', errorMessage: 'Protokollversion, Nachrichten-ID oder Sequenznummer ist ungültig.' }
          }));
          return;
        }

        const registeredClient = clients.get(ws);
        if (registeredClient) {
          const recentIds = registeredClient.recentMessageIds ?? new Set<string>();
          if (type === 'REGISTER' || sequenceNumber <= (registeredClient.lastSequenceNumber ?? -1) || recentIds.has(messageId)) {
            ws.send(JSON.stringify({
              version: PROTOCOL_VERSION,
              type: 'ERROR',
              messageId: `err_${crypto.randomUUID()}`,
              sequenceNumber: 0,
              timestamp: Date.now(),
              payload: { errorCode: 'REPLAYED_OR_OUT_OF_ORDER_MESSAGE', errorMessage: 'Doppelte oder nicht monoton fortlaufende Nachricht abgelehnt.' }
            }));
            return;
          }
          registeredClient.lastSequenceNumber = sequenceNumber;
          recentIds.add(messageId);
          if (recentIds.size > 256) recentIds.delete(recentIds.values().next().value as string);
          registeredClient.recentMessageIds = recentIds;
        } else if (type !== 'REGISTER') {
          ws.send(JSON.stringify({
            version: PROTOCOL_VERSION,
            type: 'ERROR',
            messageId: `err_${crypto.randomUUID()}`,
            sequenceNumber: 0,
            timestamp: Date.now(),
            payload: { errorCode: 'REGISTER_REQUIRED', errorMessage: 'Dieses Gerät muss zuerst registriert werden.' }
          }));
          return;
        }

        if (!type || typeof type !== 'string') {
          ws.send(JSON.stringify({
            version: PROTOCOL_VERSION,
            type: 'ERROR',
            messageId: `err_${Date.now()}`,
            sequenceNumber: 0,
            timestamp: Date.now(),
            payload: { errorCode: 'INVALID_ENVELOPE', errorMessage: 'Ungültiges Nachrichtenformat: type fehlt' }
          }));
          return;
        }

        switch (type) {
          // 1. DEVICE REGISTRATION
          case 'REGISTER': {
            const { deviceId, role, identityPublicKeyBase64, savedPairingId } = payload || {};
            if (typeof deviceId !== 'string' || !deviceId || (role !== 'admin' && role !== 'remote') ||
                !isValidP256PublicKeyBase64(identityPublicKeyBase64)) {
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'ERROR',
                messageId: `err_${crypto.randomUUID()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                payload: { errorCode: 'INVALID_REGISTRATION', errorMessage: 'deviceId und gültige Rolle (admin/remote) erforderlich.' }
              }));
              return;
            }

            // A saved pairing ID alone is not credentials. Bind only after the device signs a fresh challenge.
            const client: DeviceClient = {
              ws,
              deviceId,
              role,
              identityPublicKeyBase64: typeof identityPublicKeyBase64 === 'string' ? identityPublicKeyBase64 : undefined,
              pairingId: undefined,
              ip,
              connectedAt: Date.now(),
              lastSequenceNumber: sequenceNumber,
              recentMessageIds: new Set<string>([messageId])
            };
            clients.set(ws, client);

            if (typeof savedPairingId === 'string' && savedPairingId.length > 0) {
              const trusted = trustedPairings.get(savedPairingId);
              if (!trusted) {
                ws.send(JSON.stringify({
                  version: PROTOCOL_VERSION,
                  type: 'ERROR',
                  messageId: `err_${crypto.randomUUID()}`,
                  sequenceNumber: 0,
                  timestamp: Date.now(),
                  payload: { errorCode: 'UNKNOWN_PAIRING', errorMessage: 'Der Server kennt diese Gerätebindung nicht mehr. Bitte Geräte neu koppeln.' }
                }));
                sendUnpairedRegistration(ws, deviceId, role);
                break;
              }
              const expectedIdentity = role === 'admin' ? trusted.adminIdentityKeyBase64 : trusted.remoteIdentityKeyBase64;
              if (!identityPublicKeyBase64 || identityPublicKeyBase64 !== expectedIdentity) {
                ws.send(JSON.stringify({
                  version: PROTOCOL_VERSION,
                  type: 'ERROR',
                  messageId: `err_${crypto.randomUUID()}`,
                  sequenceNumber: 0,
                  timestamp: Date.now(),
                  payload: { errorCode: 'IDENTITY_MISMATCH', errorMessage: 'Die gespeicherte Geräteidentität stimmt nicht mit der Kopplung überein.' }
                }));
                sendUnpairedRegistration(ws, deviceId, role);
                break;
              }

              const challenge = crypto.randomBytes(32);
              registrationChallenges.set(ws, {
                pairingId: savedPairingId,
                challenge,
                deviceId,
                role,
                identityPublicKeyBase64
              });
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'REGISTER_ACK',
                messageId: `ack_${crypto.randomUUID()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                payload: {
                  status: 'AUTH_REQUIRED',
                  deviceId,
                  role,
                  challengeBase64: challenge.toString('base64')
                }
              }));
              // Do not send ICE configuration until the device has proved possession of its private identity key.
              break;
            }

            ws.send(JSON.stringify({
              version: PROTOCOL_VERSION,
              type: 'REGISTER_ACK',
              messageId: `ack_${crypto.randomUUID()}`,
              sequenceNumber: 0,
              timestamp: Date.now(),
              payload: { status: 'REGISTERED', deviceId, role }
            }));
            ws.send(JSON.stringify({
              version: PROTOCOL_VERSION,
              type: 'ICE_SERVERS',
              messageId: `ice_${crypto.randomUUID()}`,
              sequenceNumber: 0,
              timestamp: Date.now(),
              payload: generateEphemeralTurnCredentials(deviceId)
            }));
            break;
          }

          case 'REGISTER_AUTH': {
            const registration = registrationChallenges.get(ws);
            const client = clients.get(ws);
            const { pairingId: requestedPairingId, deviceId, role, identityPublicKeyBase64, challengeBase64, signatureBase64 } = payload || {};
            const trusted = typeof requestedPairingId === 'string' ? trustedPairings.get(requestedPairingId) : undefined;
            const expectedIdentity = role === 'admin' ? trusted?.adminIdentityKeyBase64 : trusted?.remoteIdentityKeyBase64;
            const encodedChallenge = typeof challengeBase64 === 'string' ? challengeBase64 : '';

            if (!registration || !client || !trusted ||
                requestedPairingId !== registration.pairingId || deviceId !== registration.deviceId ||
                role !== registration.role || identityPublicKeyBase64 !== registration.identityPublicKeyBase64 ||
                identityPublicKeyBase64 !== expectedIdentity || encodedChallenge !== registration.challenge.toString('base64') ||
                typeof signatureBase64 !== 'string') {
              registrationChallenges.delete(ws);
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'ERROR',
                messageId: `err_${crypto.randomUUID()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                payload: { errorCode: 'INVALID_REGISTRATION_PROOF', errorMessage: 'Geräte-Authentifizierung fehlgeschlagen.' }
              }));
              return;
            }

            let signatureValid = false;
            try {
              const publicKey = crypto.createPublicKey({
                key: Buffer.from(identityPublicKeyBase64, 'base64'),
                format: 'der',
                type: 'spki'
              });
              signatureValid = crypto.verify(
                'sha256',
                registration.challenge,
                publicKey,
                Buffer.from(signatureBase64, 'base64')
              );
            } catch {
              signatureValid = false;
            }
            registrationChallenges.delete(ws);
            if (!signatureValid) {
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'ERROR',
                messageId: `err_${crypto.randomUUID()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                payload: { errorCode: 'INVALID_REGISTRATION_SIGNATURE', errorMessage: 'Die kryptografische Identitätsprüfung ist fehlgeschlagen.' }
              }));
              return;
            }

            // Evict a previous socket for the same authenticated identity to avoid duplicate command recipients.
            for (const [oldWs, oldClient] of clients.entries()) {
              if (oldWs !== ws && oldClient.pairingId === requestedPairingId && oldClient.role === role &&
                  oldClient.identityPublicKeyBase64 === identityPublicKeyBase64) {
                oldClient.pairingId = undefined;
                oldWs.close(4001, 'Replaced by authenticated reconnect');
              }
            }
            client.pairingId = requestedPairingId;
            const active = activePairings.get(requestedPairingId);
            if (active) {
              if (role === 'admin') active.adminWs = ws;
              else active.remoteWs = ws;
            }

            ws.send(JSON.stringify({
              version: PROTOCOL_VERSION,
              type: 'REGISTER_ACK',
              messageId: `ack_${crypto.randomUUID()}`,
              sequenceNumber: 0,
              timestamp: Date.now(),
              pairingId: requestedPairingId,
              payload: { status: 'AUTHENTICATED', deviceId, role }
            }));
            ws.send(JSON.stringify({
              version: PROTOCOL_VERSION,
              type: 'ICE_SERVERS',
              messageId: `ice_${crypto.randomUUID()}`,
              sequenceNumber: 0,
              timestamp: Date.now(),
              pairingId: requestedPairingId,
              payload: generateEphemeralTurnCredentials(deviceId)
            }));

            // Notify both authenticated peers only after the new socket has its ICE configuration.
            // This lets the controller reliably re-offer after the other device reconnects.
            for (const [peerWs, peerClient] of clients.entries()) {
              if (peerWs !== ws && peerClient.pairingId === requestedPairingId && peerClient.role !== role && peerWs.readyState === WebSocket.OPEN) {
                const onlinePayload = { deviceId, role };
                peerWs.send(JSON.stringify({
                  version: PROTOCOL_VERSION,
                  type: 'PEER_ONLINE',
                  messageId: `online_${crypto.randomUUID()}`,
                  sequenceNumber: 0,
                  timestamp: Date.now(),
                  pairingId: requestedPairingId,
                  payload: onlinePayload
                }));
                ws.send(JSON.stringify({
                  version: PROTOCOL_VERSION,
                  type: 'PEER_ONLINE',
                  messageId: `online_${crypto.randomUUID()}`,
                  sequenceNumber: 0,
                  timestamp: Date.now(),
                  pairingId: requestedPairingId,
                  payload: { deviceId: peerClient.deviceId, role: peerClient.role }
                }));
                break;
              }
            }
            break;
          }

          // 2. PAIRING: THE TARGET DEVICE CREATES AND DISPLAYS THE ONE-TIME PIN
          case 'PAIRING_INIT': {
            const target = clients.get(ws);
            if (!target || target.role !== 'remote') {
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'ERROR',
                messageId: `err_${crypto.randomUUID()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                payload: { errorCode: 'INVALID_PAIRING_ROLE', errorMessage: 'Der Einmal-Code muss auf dem Zielgerät erzeugt werden.' }
              }));
              return;
            }
            if (!checkRateLimit(ip)) {
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'ERROR',
                messageId: `err_${crypto.randomUUID()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                payload: { errorCode: 'RATE_LIMIT_EXCEEDED', errorMessage: 'Zu viele Pairing-Versuche. Bitte warten.' }
              }));
              return;
            }

            const { code, deviceId, deviceName, ephemeralPublicKeyBase64, identityPublicKeyBase64, nonceBase64 } = payload || {};
            if (typeof code !== 'string' || !/^\d{6}$/.test(code) ||
                deviceId !== target.deviceId || identityPublicKeyBase64 !== target.identityPublicKeyBase64 ||
                !isValidP256PublicKeyBase64(ephemeralPublicKeyBase64) ||
                !isValidP256PublicKeyBase64(identityPublicKeyBase64) ||
                !isValidNonceBase64(nonceBase64)) {
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'ERROR',
                messageId: `err_${crypto.randomUUID()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                payload: { errorCode: 'INVALID_PAIRING_INIT', errorMessage: 'PIN oder kryptografische Pairing-Daten sind ungültig.' }
              }));
              return;
            }

            for (const [oldCode, old] of pendingPairings.entries()) {
              if (Date.now() - old.createdAt > PAIRING_TTL_MS || old.targetWs.readyState !== WebSocket.OPEN) {
                pendingPairings.delete(oldCode);
              }
            }
            for (const [oldCode, old] of pendingPairings.entries()) {
              if (old.targetWs === ws) pendingPairings.delete(oldCode);
            }
            const previous = pendingPairings.get(code);
            if (previous && previous.targetWs !== ws) {
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'ERROR',
                messageId: `err_${crypto.randomUUID()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                payload: { errorCode: 'PIN_COLLISION', errorMessage: 'PIN bereits aktiv. Bitte einen neuen Zufalls-PIN erzeugen.' }
              }));
              return;
            }

            pendingPairings.set(code, {
              targetWs: ws,
              code,
              createdAt: Date.now(),
              targetDeviceId: deviceId || target.deviceId,
              targetDeviceName: typeof deviceName === 'string' ? deviceName : target.deviceId,
              targetEphemeralKeyBase64: ephemeralPublicKeyBase64,
              targetIdentityKeyBase64: identityPublicKeyBase64,
              targetNonceBase64: nonceBase64
            });

            ws.send(JSON.stringify({
              version: PROTOCOL_VERSION,
              type: 'PAIRING_INIT_ACK',
              messageId: `ack_${crypto.randomUUID()}`,
              sequenceNumber: 0,
              timestamp: Date.now(),
              payload: { code, ttlSeconds: Math.floor(PAIRING_TTL_MS / 1000) }
            }));
            break;
          }

          // 3. PAIRING: THE CONTROLLER ENTERS THE PIN SHOWN ON THE TARGET
          case 'PAIRING_SUBMIT': {
            const admin = clients.get(ws);
            if (!admin || admin.role !== 'admin') {
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'ERROR',
                messageId: `err_${crypto.randomUUID()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                payload: { errorCode: 'INVALID_PAIRING_ROLE', errorMessage: 'Nur die Fernbedienung darf den Zielgeräte-PIN eingeben.' }
              }));
              return;
            }
            if (!checkRateLimit(ip)) {
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'ERROR',
                messageId: `err_${crypto.randomUUID()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                payload: { errorCode: 'RATE_LIMIT_EXCEEDED', errorMessage: 'Zu viele Pairing-Versuche. Bitte 15 Minuten warten.' }
              }));
              return;
            }

            const { code, remoteDeviceId, ephemeralPublicKeyBase64, identityPublicKeyBase64, nonceBase64, deviceName } = payload || {};
            const pending = typeof code === 'string' ? pendingPairings.get(code) : undefined;
            if (!pending || Date.now() - pending.createdAt > PAIRING_TTL_MS) {
              if (typeof code === 'string') pendingPairings.delete(code);
              recordFailedAttempt(ip);
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'ERROR',
                messageId: `err_${crypto.randomUUID()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                payload: { errorCode: 'INVALID_CODE', errorMessage: 'Ungültiger oder abgelaufener Pairing-PIN.' }
              }));
              return;
            }
            if (pending.targetWs === ws || pending.targetWs.readyState !== WebSocket.OPEN) {
              recordFailedAttempt(ip);
              pendingPairings.delete(code);
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'ERROR',
                messageId: `err_${crypto.randomUUID()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                payload: { errorCode: 'INVALID_PAIRING_PEER', errorMessage: 'Das Zielgerät ist nicht mehr erreichbar.' }
              }));
              return;
            }
            if (remoteDeviceId !== admin.deviceId || identityPublicKeyBase64 !== admin.identityPublicKeyBase64 ||
                !isValidP256PublicKeyBase64(ephemeralPublicKeyBase64) ||
                !isValidP256PublicKeyBase64(identityPublicKeyBase64) ||
                !isValidNonceBase64(nonceBase64)) {
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'ERROR',
                messageId: `err_${crypto.randomUUID()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                payload: { errorCode: 'INVALID_PAIRING_SUBMIT', errorMessage: 'Kryptografische Pairing-Daten sind ungültig.' }
              }));
              return;
            }

            const pairingId = computePairingId(identityPublicKeyBase64, pending.targetIdentityKeyBase64);
            const remoteClient = clients.get(pending.targetWs);
            const active: ActivePairing = {
              pairingId,
              code,
              adminWs: ws,
              remoteWs: pending.targetWs,
              adminIdentityKeyBase64: identityPublicKeyBase64,
              remoteIdentityKeyBase64: pending.targetIdentityKeyBase64,
              createdAt: Date.now(),
              confirmations: new Set<WebSocket>(),
              commits: new Set<WebSocket>(),
              committed: false
            };
            activePairings.set(pairingId, active);
            pendingPairings.delete(code); // consume the one-time PIN as soon as it is used
            resetRateLimit(ip);

            ws.send(JSON.stringify({
              version: PROTOCOL_VERSION,
              type: 'PAIRING_RESPONSE',
              messageId: `pair_resp_${crypto.randomUUID()}`,
              sequenceNumber: 0,
              timestamp: Date.now(),
              pairingId,
              payload: {
                code,
                remoteDeviceId: remoteClient?.deviceId || pending.targetDeviceId,
                remoteDeviceName: pending.targetDeviceName,
                ephemeralPublicKeyBase64: pending.targetEphemeralKeyBase64,
                identityPublicKeyBase64: pending.targetIdentityKeyBase64,
                nonceBase64: pending.targetNonceBase64
              }
            }));

            pending.targetWs.send(JSON.stringify({
              version: PROTOCOL_VERSION,
              type: 'PAIRING_HANDSHAKE_INIT',
              messageId: `pair_init_${crypto.randomUUID()}`,
              sequenceNumber: 0,
              timestamp: Date.now(),
              pairingId,
              payload: {
                code,
                adminDeviceId: remoteDeviceId || admin.deviceId,
                ephemeralPublicKeyBase64,
                identityPublicKeyBase64,
                nonceBase64,
                deviceName: deviceName || admin.deviceId
              }
            }));
            break;
          }

          // 4. MUTUAL SAS CONFIRMATION. The server never treats one click as mutual consent.
          case 'PAIRING_CONFIRM': {
            const { pairingId: payloadPairingId, authProofBase64 } = payload || {};
            const effectivePairingId = pairingId || payloadPairingId;
            const active = effectivePairingId ? activePairings.get(effectivePairingId) : undefined;
            const isMember = !!active && (active.adminWs === ws || active.remoteWs === ws);
            if (!active || !isMember || payloadPairingId !== effectivePairingId || !isValidAuthProofBase64(authProofBase64)) {
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'ERROR',
                messageId: `err_${crypto.randomUUID()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                payload: { errorCode: 'INVALID_PAIRING_CONFIRM', errorMessage: 'Pairing-Bestätigung ist ungültig oder gehört nicht zu dieser Sitzung.' }
              }));
              return;
            }

            const peerWs = active.adminWs === ws ? active.remoteWs : active.adminWs;
            if (peerWs.readyState !== WebSocket.OPEN) {
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'ERROR',
                messageId: `err_${crypto.randomUUID()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                pairingId: effectivePairingId,
                payload: { errorCode: 'PEER_OFFLINE', errorMessage: 'Das andere Gerät ist nicht mehr verbunden.' }
              }));
              return;
            }

            active.confirmations.add(ws);
            peerWs.send(JSON.stringify({
              version: PROTOCOL_VERSION,
              type: 'PAIRING_CONFIRM',
              messageId: messageId || `confirm_${crypto.randomUUID()}`,
              sequenceNumber: sequenceNumber || 0,
              timestamp: Date.now(),
              pairingId: effectivePairingId,
              payload: { authProofBase64, pairingId: effectivePairingId }
            }));

            break;
          }

          // Commit is accepted only after this client sent its proof and also verified its peer's proof.
          case 'PAIRING_COMMIT': {
            const { pairingId: payloadPairingId } = payload || {};
            const effectivePairingId = pairingId || payloadPairingId;
            const active = effectivePairingId ? activePairings.get(effectivePairingId) : undefined;
            const member = !!active && (active.adminWs === ws || active.remoteWs === ws);
            const otherWs = active ? (active.adminWs === ws ? active.remoteWs : active.adminWs) : undefined;
            if (!active || !member || payloadPairingId !== effectivePairingId ||
                !active.confirmations.has(ws) || !otherWs || !active.confirmations.has(otherWs)) {
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'ERROR',
                messageId: `err_${crypto.randomUUID()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                payload: { errorCode: 'INVALID_PAIRING_COMMIT', errorMessage: 'Die beidseitigen Sicherheitsnachweise liegen noch nicht vor.' }
              }));
              return;
            }
            active.commits.add(ws);
            if (active.commits.size === 2 && !active.committed) {
              const adminClient = clients.get(active.adminWs);
              const remoteClient = clients.get(active.remoteWs);
              if (!adminClient || !remoteClient) return;
              active.committed = true;
              trustedPairings.set(effectivePairingId, {
                pairingId: effectivePairingId,
                adminIdentityKeyBase64: active.adminIdentityKeyBase64,
                remoteIdentityKeyBase64: active.remoteIdentityKeyBase64,
                createdAt: Date.now()
              });
              try {
                persistTrustedPairings();
              } catch {
                trustedPairings.delete(effectivePairingId);
                activePairings.delete(effectivePairingId);
                for (const peer of [active.adminWs, active.remoteWs]) {
                  peer.send(JSON.stringify({
                    version: PROTOCOL_VERSION,
                    type: 'ERROR',
                    messageId: `err_${crypto.randomUUID()}`,
                    sequenceNumber: 0,
                    timestamp: Date.now(),
                    payload: { errorCode: 'PAIRING_PERSISTENCE_FAILED', errorMessage: 'Gerätebindung konnte nicht sicher gespeichert werden. Es wurde keine Kopplung bestätigt.' }
                  }));
                }
                return;
              }
              adminClient.pairingId = effectivePairingId;
              remoteClient.pairingId = effectivePairingId;
              const successPayload = { pairingId: effectivePairingId, status: 'PAIRED', pairedAt: Date.now() };
              for (const peer of [active.adminWs, active.remoteWs]) {
                peer.send(JSON.stringify({
                  version: PROTOCOL_VERSION,
                  type: 'PAIRING_SUCCESS',
                  messageId: `success_${crypto.randomUUID()}`,
                  sequenceNumber: 0,
                  timestamp: Date.now(),
                  pairingId: effectivePairingId,
                  payload: successPayload
                }));
              }
              for (const peer of [active.adminWs, active.remoteWs]) {
                const peerClient = clients.get(peer === active.adminWs ? active.remoteWs : active.adminWs);
                peer.send(JSON.stringify({
                  version: PROTOCOL_VERSION,
                  type: 'PEER_ONLINE',
                  messageId: `online_${crypto.randomUUID()}`,
                  sequenceNumber: 0,
                  timestamp: Date.now(),
                  pairingId: effectivePairingId,
                  payload: { deviceId: peerClient?.deviceId || '', role: peerClient?.role || '' }
                }));
              }
              // The identity pair and trusted binding are persisted; keep ephemeral ECDH material only
              // for the short handshake, not for the lifetime of the persistent pairing.
              activePairings.delete(effectivePairingId);
            }
            break;
          }

          // 5. PAIRING REVOCATION
          case 'PAIRING_REVOKED': {
            const sender = clients.get(ws);
            const targetPairingId = pairingId || sender?.pairingId;
            const active = targetPairingId ? activePairings.get(targetPairingId) : undefined;
            const isActiveMember = !!active && (active.adminWs === ws || active.remoteWs === ws);

            if (targetPairingId && sender && (sender.pairingId === targetPairingId || isActiveMember)) {
              const previousTrusted = trustedPairings.get(targetPairingId);
              trustedPairings.delete(targetPairingId);
              try {
                persistTrustedPairings();
              } catch {
                if (previousTrusted) trustedPairings.set(targetPairingId, previousTrusted);
                ws.send(JSON.stringify({
                  version: PROTOCOL_VERSION,
                  type: 'ERROR',
                  messageId: `err_${crypto.randomUUID()}`,
                  sequenceNumber: 0,
                  timestamp: Date.now(),
                  pairingId: targetPairingId,
                  payload: { errorCode: 'REVOKE_PERSISTENCE_FAILED', errorMessage: 'Der Widerruf konnte nicht dauerhaft gespeichert werden. Server-Speicher prüfen.' }
                }));
                return;
              }

              for (const [peerWs, peerClient] of clients.entries()) {
                if (peerClient.pairingId === targetPairingId) {
                  peerClient.pairingId = undefined;
                  if (peerWs !== ws && peerWs.readyState === WebSocket.OPEN) {
                    peerWs.send(JSON.stringify({
                      version: PROTOCOL_VERSION,
                      type: 'PAIRING_REVOKED',
                      messageId: `revoked_${crypto.randomUUID()}`,
                      sequenceNumber: 0,
                      timestamp: Date.now(),
                      pairingId: targetPairingId,
                      payload: { reason: 'Vom Nutzer widerrufen' }
                    }));
                  }
                }
              }
              activePairings.delete(targetPairingId);
            }
            if (sender) sender.pairingId = undefined;
            for (const [code, pending] of pendingPairings.entries()) {
              if (pending.targetWs === ws) pendingPairings.delete(code);
            }
            break;
          }

          // 6. ROUTE MESSAGES STRICTLY TO THE PAIRED PEER
          case 'SDP_OFFER':
          case 'SDP_ANSWER':
          case 'ICE_CANDIDATE':
          case 'DEVICE_STATUS':
          case 'PERMISSION_STATUS':
          case 'CONTROL_ACTION':
          case 'ACTION_RESULT':
          case 'TEXT_INPUT':
          case 'VOLUME_SET':
          case 'BRIGHTNESS_SET':
          case 'FLASHLIGHT_SET':
          case 'VIBRATION_TEST':
          case 'CLIPBOARD_TRANSFER':
          case 'AUDIO_START':
          case 'AUDIO_PAUSE':
          case 'AUDIO_RESUME':
          case 'AUDIO_STOP':
          case 'AUDIO_STATUS':
          case 'AUDIO_FLOW_CONTROL':
          case 'AUDIO_VOLUME':
          case 'DISCONNECT': {
            const sender = clients.get(ws);
            const targetPairingId = sender?.pairingId;

            if (!sender || !targetPairingId || (pairingId && pairingId !== targetPairingId)) {
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'ERROR',
                messageId: `err_${Date.now()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                payload: { errorCode: 'UNAUTHORIZED_PAIRING', errorMessage: 'Keine aktive Pairing-ID verknüpft.' }
              }));
              return;
            }

            let delivered = false;
            for (const [peerWs, peerClient] of clients.entries()) {
              if (peerWs !== ws && peerWs.readyState === WebSocket.OPEN) {
                if (peerClient.pairingId === targetPairingId && peerClient.role !== sender.role) {
                  peerWs.send(JSON.stringify({
                    version: message.version || PROTOCOL_VERSION,
                    type: message.type,
                    messageId: message.messageId || `msg_${Date.now()}`,
                    sequenceNumber: message.sequenceNumber || 0,
                    timestamp: message.timestamp || Date.now(),
                    pairingId: targetPairingId,
                    payload: message.payload
                  }));
                  delivered = true;
                }
              }
            }

            if (!delivered && type !== 'DISCONNECT') {
              ws.send(JSON.stringify({
                version: PROTOCOL_VERSION,
                type: 'ERROR',
                messageId: `err_${Date.now()}`,
                sequenceNumber: 0,
                timestamp: Date.now(),
                payload: { errorCode: 'PEER_OFFLINE', errorMessage: 'Gekoppeltes Zielgerät ist aktuell offline.' }
              }));
            }
            break;
          }

          // 7. KEEP-ALIVE PING / PONG
          case 'PING': {
            ws.send(JSON.stringify({
              version: PROTOCOL_VERSION,
              type: 'PONG',
              messageId: `pong_${Date.now()}`,
              sequenceNumber: sequenceNumber || 0,
              timestamp: Date.now(),
              payload: { echoTimestamp: message.timestamp }
            }));
            break;
          }

          default: {
            ws.send(JSON.stringify({
              version: PROTOCOL_VERSION,
              type: 'ERROR',
              messageId: `err_${Date.now()}`,
              sequenceNumber: 0,
              timestamp: Date.now(),
              payload: { errorCode: 'UNKNOWN_MESSAGE_TYPE', errorMessage: `Unbekannter Nachrichtentyp: ${type}` }
            }));
            break;
          }
        }
      } catch (err: any) {
        ws.send(JSON.stringify({
          version: PROTOCOL_VERSION,
          type: 'ERROR',
          messageId: `err_${Date.now()}`,
          sequenceNumber: 0,
          timestamp: Date.now(),
          payload: { errorCode: 'MALFORMED_JSON', errorMessage: 'Fehler beim Parsen der JSON-Nachricht.' }
        }));
      }
    });

    ws.on('close', () => {
      const client = clients.get(ws);
      registrationChallenges.delete(ws);
      for (const [code, pending] of pendingPairings.entries()) {
        if (pending.targetWs === ws) pendingPairings.delete(code);
      }
      for (const [pairingId, active] of activePairings.entries()) {
        if (!trustedPairings.has(pairingId) && (active.adminWs === ws || active.remoteWs === ws)) {
          activePairings.delete(pairingId);
        }
      }
      if (client?.pairingId) {
        // Notify peer about disconnect
        for (const [peerWs, peerClient] of clients.entries()) {
          if (peerWs !== ws && peerClient.pairingId === client.pairingId && peerWs.readyState === WebSocket.OPEN) {
            peerWs.send(JSON.stringify({
              version: PROTOCOL_VERSION,
              type: 'DISCONNECT',
              messageId: `disc_${Date.now()}`,
              sequenceNumber: 0,
              timestamp: Date.now(),
              pairingId: client.pairingId,
              payload: { deviceId: client.deviceId, reason: 'Verbindung geschlossen' }
            }));
          }
        }
      }
      clients.delete(ws);
    });
  });

  return { server, wss };
}

// Start standalone server when executed directly
if (process.argv[1] && process.argv[1].endsWith('signaling.ts') || process.argv[1]?.endsWith('signaling.js')) {
  const { server } = createServerInstance();
  server.listen(PORT, () => {
    console.log(`[Signaling Server] Listening on port ${PORT} (Protocol v${PROTOCOL_VERSION})`);
  });
}
