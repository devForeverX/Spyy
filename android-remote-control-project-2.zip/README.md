# Native Android Phone-to-Phone Remote Control

Vollständig natives Android-Studio-Projekt in Kotlin mit Jetpack Compose zur sicheren, dauerhaften Kopplung und Fernsteuerung zwischen zwei physischen Android-Smartphones über WebRTC und einen eigenständigen Node.js/Coturn-Signalisierungsserver.

---

## 1. Systemübersicht & Architektur

Das Gesamtsystem besteht aus zwei unabhängigen Komponenten:

```
├── android/            # Natives Android Studio (Kotlin, Jetpack Compose, Material 3)
│   ├── app/            # Android App (Services, Accessibility, IME, WebRTC, Crypto)
│   └── gradlew         # Gradle 8.7 Wrapper (ausführbar, UNIX-Permissions 0755)
├── server/             # Signalisierungsserver & Coturn TURN-Infrastruktur
│   ├── src/            # Node.js / TypeScript WSS-Signalisierung & REST API
│   ├── test/           # Automatisierte Testsuite (Pairing, Routing, Healthz)
│   ├── Dockerfile      # Pinned Node 22 Alpine Multi-Stage Production Image
│   └── docker-compose.yml # Signalisierung & Coturn STUN/TURN Container
├── scripts/            # Build-, Test- und Release-Packaging-Skripte
├── FINAL_BUILD_REPORT.md # Wahrheitsgemäßer Verifikationsbericht
└── README.md           # Diese Dokumentation
```

---

## 2. Android-App (`android/`)

### Voraussetzungen
- **Android Studio**: Hedgehog (2023.1.1), Ladybug, Koala oder neuer.
- **JDK**: Java 17 oder Java 21.
- **Android SDK**: `compileSdk = 35` (Android 15), `minSdk = 26` (Android 8.0 Oreo).
- **Zwei Android-Smartphones**: Ein Admin-Controller-Smartphone und ein Remote-Zielgerät.

### Kompilierung der APK
```bash
cd android
chmod +x gradlew
./gradlew assembleDebug
```
Die fertige APK liegt unter:
`app/build/outputs/apk/debug/app-debug.apk`

### Ausführung der Unit-Tests
```bash
./gradlew testDebugUnitTest
```
Die Tests verifizieren:
- **`PairingCrypto`**: ECDH Key Agreement auf der P-256 (secp256r1) Kurve, HKDF-Extract & HKDF-Expand, 6-stelliger SAS-Code-Abgleich und Authentifizierungs-Proof-Validierung.
- **`ProtocolJson`**: Strukturierte JSON-Envelope-Serialisierung und Interoperabilität mit dem TypeScript-Server.
- **`AudioPacket` & `JitterBuffer`**: Binäres Paket-Layout (17 Byte Header, Magic Bytes, PTS-Timing, Längenprüfung und Backpressure-Wasserzeichen).

### Installation via ADB
```bash
# Auf erstem Smartphone (Admin):
adb -s <DEVICE_1_ID> install -r app/build/outputs/apk/debug/app-debug.apk

# Auf zweitem Smartphone (Remote-Zielgerät):
adb -s <DEVICE_2_ID> install -r app/build/outputs/apk/debug/app-debug.apk
```

---

## 3. Erforderliche Android-Systemdienste auf dem Zielgerät

Damit das Remote-Gerät Befehle ausführen kann, müssen folgende offizielle Android-Dienste einmalig in den Systemeinstellungen aktiviert werden:

1. **Bedienungshilfen-Dienst (Accessibility Service)**:
   - *Pfad*: `Einstellungen` $\rightarrow$ `Bedienungshilfen` $\rightarrow$ `Remote Control Navigation Service` $\rightarrow$ **Aktivieren**.
   - *Funktion*: Ausführen von **Zurück (Back)**, **Home**, **Recent Apps (Task-Switcher)**, **Benachrichtigungen** und **Schnelleinstellungen**.
2. **Eingabemethode (Remote Input Method Service / IME)**:
   - *Pfad*: `Einstellungen` $\rightarrow$ `System` $\rightarrow$ `Sprachen & Tastatur` $\rightarrow$ `Bildschirmtastatur verwalten` $\rightarrow$ **Remote Control Tastatur aktivieren**.
   - *Funktion*: Direktes Einfügen von Text via `currentInputConnection.commitText` in fokussierte Eingabefelder sowie Senden von Enter und Backspace.
3. **Systemeinstellungen ändern (WRITE_SETTINGS)**:
   - *Pfad*: In der App im Tab *Rechte* tippen $\rightarrow$ **Systemeinstellungen ändern** erlauben.
   - *Funktion*: Ändern der realen Display-Helligkeit (`Settings.System.putInt`).
4. **Kamera & Benachrichtigungen**:
   - Kamera-Berechtigung für die LED-Taschenlampe (`CameraManager.setTorchMode`).
   - Benachrichtigungs-Berechtigung für Statusanzeigen. Die aktive Bildschirmfreigabe nutzt einen Android-Foreground-Service mit Systemanzeige; Sichtbarkeit im Benachrichtigungsfeld hängt zusätzlich von Android-Version und Benachrichtigungseinstellungen ab.
5. **Live-Bildschirm & freie Gesten**:
   - Am Zielgerät im Tab *Rechte* die Bildschirmfreigabe starten und der nativen Android-Abfrage zustimmen.
   - Der Controller öffnet danach den Tab *Bildschirm*. Sobald ein echtes WebRTC-Videobild ankommt, lassen sich innerhalb des angezeigten Bildes Tippen und Wischen senden.
   - Die Gestensteuerung erfordert den aktivierten Bedienungshilfe-Dienst. Android kann Eingaben auf geschützten Systemoberflächen/Apps weiterhin blockieren.

---

## 4. Kopplung (Pairing) & Verbindung

1. **Rollenwahl**:
   - Gerät A wählt **Admin-Gerät (Fernbedienung)**.
   - Gerät B wählt **Remote-Gerät (Zielgerät)**.
   - Beide Geräte müssen dieselbe erreichbare Signalisierungsserver-Adresse verwenden.
2. **Einmalcode**:
   - Das **Zielgerät** erzeugt mit `SecureRandom` einen kryptografisch zufälligen sechsstelligen Einmalcode mit fünf Minuten Gültigkeit.
   - Nur die **Fernbedienung** gibt diesen Code ein. Auf dem Zielgerät muss kein PIN eingetippt werden.
   - Während des Pairing-Handshakes wird der Code auf dem Zielgerät ausgeblendet.
3. **Kryptografischer Handshake**:
   - Beide Geräte tauschen kurzlebige P-256-ECDH-Öffentlichschlüssel und Nonces aus.
   - Beide berechnen das gemeinsame Geheimnis und leiten über HKDF, gebunden an den Code und die Nonces, denselben SAS-Bestätigungscode ab.
4. **Sicherheitsabgleich & Persistenz**:
   - Vergleiche den SAS-Code auf beiden Smartphones und bestätige lokal auf beiden Geräten.
   - Die Pairing-Daten werden mit einem Schlüssel aus dem Android Keystore verschlüsselt abgelegt.
5. **Wiederverbindung & Widerruf**:
   - Nach einem Verbindungsabbruch beweist jedes Gerät den Besitz seines Identitätsschlüssels durch Signieren einer frischen Server-Challenge. Die gespeicherte Pairing-ID allein reicht nicht.
   - Bei einer Wiederverbindung wird kein neuer PIN benötigt. Nach einem Server-Neustart müssen die persistenten Server-Pairings vorhanden sein.
   - Durch **Kopplung widerrufen** wird die lokale Bindung gelöscht und der Server angewiesen, die serverseitige Bindung und aktive Sitzung zu widerrufen.

---

## 5. Signalisierungsserver & Coturn STUN/TURN (`server/`)

### Lokale Entwicklung & Tests
```bash
cd server
npm ci
npm run build
npm test
npm run dev
```

### Docker-Bereitstellung (Production)
```bash
cd server
cp .env.example .env
# Generiere sicheres Secret:
openssl rand -hex 32
# Trage Secret in COTURN_STATIC_AUTH_SECRET ein und hinterlege TLS-Zertifikate in certs/
docker compose up -d --build
```
Healthcheck prüfen:
```bash
curl -s http://localhost:8443/healthz
```

---

## 6. Release-ZIP erstellen

Das Packaging-Skript hat eine eigene kleine npm-Manifestdatei und benötigt `jszip`. Auf einem Rechner mit Netzwerk einmal installieren und anschließend paketieren:

```bash
cd scripts
npm install
npm run package
```

Das Archiv wird im Projektstamm als `android-remote-control-project.zip` erzeugt. Es enthält ausschließlich:
- `android/` (inklusive ausführbarem `./gradlew` mit 0755 Rechten)
- `server/` (inklusive `Dockerfile`, `docker-compose.yml`, Quellcode und Tests)
- `scripts/` (Packaging-Skripte)
- `README.md` & `FINAL_BUILD_REPORT.md`
- Keine `node_modules`, keine build-Artefakte, keine Secrets oder Browser-Democodes.


## 7. Verifikationsstatus und Grenzen

Der aktuelle, umgebungsbezogene Prüfstatus sowie die tatsächlichen Ergebnisse sind in `FINAL_BUILD_REPORT.md` dokumentiert. Die Quelltextänderungen und isolierten Host-Tests sind kein Ersatz für einen erfolgreichen Android-Gradle-Build und Tests mit zwei realen Smartphones. Wenn dort `BLOCKED` oder `NOT TESTED` steht, ist die betreffende Funktion noch nicht als end-to-end verifiziert anzusehen.

Der Quellcode enthält inzwischen einen Live-Bildschirm-/Touchpfad über `MediaProjection`, WebRTC-Video und den Android-Bedienungshilfe-Dienst. Dieser Pfad ist in dieser Umgebung **nicht kompiliert und nicht auf zwei echten Geräten getestet**; deshalb ist er nicht als nachweislich funktionsfähig zu behandeln. Die hier vorhandene Screenshot-Systemaktion überträgt weiterhin kein Bild zurück und ersetzt die Live-Bildschirmfreigabe nicht. Siehe `FINAL_BUILD_REPORT.md` für den aktuellen Verifikationsstatus.
