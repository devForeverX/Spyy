package com.remote.androidcontroller.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.SettingsRemote
import androidx.compose.material3.Card
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.remote.androidcontroller.ui.theme.DarkBorder
import com.remote.androidcontroller.ui.theme.DarkSurface
import com.remote.androidcontroller.ui.theme.DarkSurfaceElevated
import com.remote.androidcontroller.ui.theme.EmeraldPrimary
import com.remote.androidcontroller.ui.theme.TextPrimary
import com.remote.androidcontroller.ui.theme.TextSecondary

@Composable
fun MainModeScreen(
    serverUrl: String,
    errorMessage: String?,
    onServerUrlChange: (String) -> Unit,
    onSelectAdminMode: () -> Unit,
    onSelectRemoteMode: () -> Unit,
    modifier: Modifier = Modifier
) {
    val parsedUrl = android.net.Uri.parse(serverUrl.trim())
    val host = parsedUrl.host?.lowercase().orEmpty()
    val localCleartext = host == "localhost" || host == "127.0.0.1" || host == "10.0.2.2" ||
        host.startsWith("192.168.") || host.startsWith("10.") ||
        (host.startsWith("172.") && (host.substringAfter("172.").substringBefore('.').toIntOrNull() ?: 0) in 16..31)
    val validServerUrl = host.isNotBlank() && (parsedUrl.scheme.equals("wss", true) ||
        (parsedUrl.scheme.equals("ws", true) && localCleartext)) && parsedUrl.port != 0 && parsedUrl.port <= 65535
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .background(DarkSurfaceElevated, CircleShape)
                .border(1.5.dp, EmeraldPrimary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.SettingsRemote,
                contentDescription = null,
                tint = EmeraldPrimary,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Android Phone Remote Control",
            style = MaterialTheme.typography.headlineLarge,
            color = TextPrimary
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Wähle die Rolle dieses Smartphones für die Kopplung:",
            color = TextSecondary,
            fontSize = 15.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = serverUrl,
            onValueChange = onServerUrlChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Signalisierungsserver (WSS-Adresse)") },
            placeholder = { Text("wss://dein-server.example:8443") },
            isError = !validServerUrl,
            supportingText = {
                Text(
                    if (validServerUrl) "Gespeichert auf diesem Gerät. Öffentliche Server müssen TLS (wss://) verwenden."
                    else "Serveradresse erforderlich. ws:// ist nur für lokale Entwicklungsserver erlaubt.",
                    color = if (validServerUrl) TextSecondary else MaterialTheme.colorScheme.error
                )
            }
        )

        if (!errorMessage.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(errorMessage, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
        }

        Spacer(modifier = Modifier.height(22.dp))

        // Role 1: Admin Controller
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(enabled = validServerUrl) { onSelectAdminMode() },
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
        ) {
            Row(
                modifier = Modifier.padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(DarkSurfaceElevated, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.SettingsRemote, contentDescription = null, tint = EmeraldPrimary)
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Text(
                        text = "Admin-Gerät (Controller)",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    Text(
                        text = "Steuere das andere Smartphone über die native Android-Fernbedienung.",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Role 2: Remote Target Device
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(enabled = validServerUrl) { onSelectRemoteMode() },
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
        ) {
            Row(
                modifier = Modifier.padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(DarkSurfaceElevated, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = EmeraldPrimary)
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Text(
                        text = "Remote-Gerät (Zielgerät)",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    Text(
                        text = "Empfängt Steuerbefehle und führt Navigation, Audio und IME aus.",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
