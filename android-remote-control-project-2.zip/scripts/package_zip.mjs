import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const outputFile = path.join(rootDir, 'android-remote-control-project.zip');

const zip = new JSZip();

const EXCLUDED_DIRS = new Set([
  'node_modules',
  '.git',
  '.gradle',
  'build',
  'dist',
  'certs',
  '.aistudio'
]);

const EXCLUDED_FILES = new Set([
  '.env',
  'pairings.json',
  'pairings.json.tmp',
  'android-remote-control-project.zip'
]);

function addDirectoryToZip(dirPath, zipFolder) {
  const items = fs.readdirSync(dirPath);

  for (const item of items) {
    if (EXCLUDED_DIRS.has(item) || EXCLUDED_FILES.has(item) || item.endsWith('.log')) {
      continue;
    }

    const fullPath = path.join(dirPath, item);
    const stat = fs.statSync(fullPath);

    if (stat.isDirectory()) {
      const childFolder = zipFolder.folder(item);
      addDirectoryToZip(fullPath, childFolder);
    } else {
      const content = fs.readFileSync(fullPath);
      const isExecutable = item === 'gradlew' || item.endsWith('.sh');
      zipFolder.file(item, content, {
        unixPermissions: isExecutable ? 0o755 : 0o644
      });
    }
  }
}

console.log('Packaging clean release into ZIP archive (Whitelist: android/, server/, scripts/, docs)...');

// 1. Android Studio Project
if (fs.existsSync(path.join(rootDir, 'android'))) {
  const androidFolder = zip.folder('android');
  addDirectoryToZip(path.join(rootDir, 'android'), androidFolder);
}

// 2. Node.js & Coturn Signaling Server
if (fs.existsSync(path.join(rootDir, 'server'))) {
  const serverFolder = zip.folder('server');
  addDirectoryToZip(path.join(rootDir, 'server'), serverFolder);
}

// 3. Build & Packaging Scripts
if (fs.existsSync(path.join(rootDir, 'scripts'))) {
  const scriptsFolder = zip.folder('scripts');
  addDirectoryToZip(path.join(rootDir, 'scripts'), scriptsFolder);
}

// 4. Root Documentation & Reports
const docFiles = ['README.md', 'FINAL_BUILD_REPORT.md'];
for (const doc of docFiles) {
  const docPath = path.join(rootDir, doc);
  if (fs.existsSync(docPath)) {
    zip.file(doc, fs.readFileSync(docPath), { unixPermissions: 0o644 });
  }
}

zip.generateAsync({
  type: 'nodebuffer',
  compression: 'DEFLATE',
  compressionOptions: { level: 9 },
  platform: 'UNIX'
})
  .then((buffer) => {
    fs.writeFileSync(outputFile, buffer);
    const stats = fs.statSync(outputFile);
    console.log(`\nSuccessfully created: ${outputFile}`);
    console.log(`Release Archive Size: ${(stats.size / 1024).toFixed(2)} KB`);
  })
  .catch((err) => {
    console.error('Error creating ZIP archive:', err);
    process.exit(1);
  });
